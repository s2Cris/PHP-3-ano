<div class="col-sm-12 mb-4">

    <div class="card shadow mb-4">
        <!-- striped é para zebrar as linhas, cada uma com uma cor-->
        <div class="table-responsive-sm mt-4">
            <h3 class="ml-3">
                Listar Funcionários
                <a class="btn btn-success float-right mb-3 mr-3" href="?p=add/funcionario"><i class="bi bi-database-fill-add"></i></a>
            </h3>

            <table class="table table-striped table-sm">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>Cargo</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php
                    include_once '../controller/FuncionarioController.php';
                    $func = new FuncionarioController();
                    $dados = $func->listar();

                    foreach ($dados as $mostrar) {
                        ?>

                    <tr>
                        <td><?= $mostrar['id'] ?></td>
                        <td><?= $mostrar['nome'] ?></td>
                        <td><?= $mostrar['email'] ?></td>
                        <td><?= $mostrar['cargo'] ?></td>
                        <td>
                            <a href="?p=editar/funcionario&id=<?= $mostrar['id'] ?>" 
                            class="btn btn-warning" 
                            title="Editar">
                                <i class="bi bi-pencil-square"></i>
                            </a>
                            <a href="?p=excluir/funcionario&id=<?= $mostrar['id'] ?>"
                            class="btn btn-danger"
                            title="Excluir"
                            onclick="return confirm('Tem certeza que deseja excluir?')">
                                <i class="bi bi-x-circle"></i>
                            </a>
                        </td>
                    </tr>

                    <?php
                    }
                    ?>

                </tbody>
            </table>
        </div>
    </div>
</div>