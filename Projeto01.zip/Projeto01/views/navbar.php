<nav class="navbar navbar-expand-lg navbar-dark bg-success">
    <a class="navbar-brand" href="?p=home"><i class="bi bi-house-door-fill"></i></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Alterna navegação">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">

            <li class="nav-item">
                <a class="nav-link" href="?p=categorias">
                    <i class="bi bi-list-task"></i> Consultar Categorias
                </a>
            <li class="nav-item">
                <a class="nav-link" href="?p=cliente">
                    <i class="bi bi-list-task"></i> Consultar Clientes
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?p=pesquisar/cliente">
                    <i class="bi bi-search"></i> Pesquisar Clientes
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?p=fornecedor">
                    <i class="bi bi-list-task"></i> Consultar Fornecedores
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?p=pesquisar/fornecedor">
                    <i class="bi bi-search"></i> Pesquisar Fornecedores
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?p=funcionario">
                    <i class="bi bi-list-task"></i> Consultar Funcionários
                </a>
            </li>
            
        </ul>
    </div>
</nav>